public class Warrior {

    private int x;
    private int y;
    private int health;

    public Warrior() {
        x = 0;
        y = 0;
        health = 100;
    }

    public void moveLeft() {
        x--;
    }
