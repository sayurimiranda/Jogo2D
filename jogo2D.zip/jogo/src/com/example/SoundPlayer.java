import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SoundPlayer {

    private ExecutorService executorService;

    public SoundPlayer() {
        executorService = Executors.newSingleThreadExecutor();
    }

    public void playSound(String filename) {
        executorService.execute(() -> {
            try {
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("resources/sounds/" + filename));
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                clip.start();
            } catch (IOException | LineUnavailableException e) {
                System.out.println("Erro ao reproduzir o som " + filename);
            }
        });
    }
