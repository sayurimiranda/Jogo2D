import java.awt.image.BufferedImage;
import java.io.IOException;

public class ImageLoader {

    public BufferedImage loadImage(String filename) {
        BufferedImage image = null;

        try {
            image = ImageIO.read(new File("resources/images/" + filename));
        } catch (IOException e) {
            System.out.println("Erro ao carregar a imagem " + filename);
        }

        return image;
    }
}
