package com.example;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Game {

    private BufferedImage background;
    private BufferedImage warriorSprite;

    private World world;
    private Warrior warrior;

    private ExecutorService executorService;

    public Game() {
        background = loadImage("background.png");
        warriorSprite = loadImage("warrior.png");

        world = new World();
        warrior = new Warrior();

        executorService = Executors.newSingleThreadExecutor();
    }

    private BufferedImage loadImage(String filename) {
        BufferedImage image = null;

        try {
            image = ImageIO.read(new File("resources/images/" + filename));
        } catch (IOException e) {
            System.out.println("Erro ao carregar a imagem " + filename);
        }

        return image;
    }

    public void run() {
        while (true) {
            update();
            render();
        }
    }

    public void update() {
        world.update();
        warrior.update();

        for (Enemy enemy : world.getEnemies()) {
            if (enemy.isCollidingWithWarrior()) {
                warrior.damage(enemy.getDamage());
            }
        }

        if (warrior.getHealth() <= 0) {
            gameOver();
        }
    }

    public void render(Graphics g) {
        g.drawImage(background, 0, 0, null);
        world.render(g);
        warrior.render(g);

        g.setColor(Color.WHITE);
        g.drawString("Score: " + warrior.getScore(), 10, 10);
    }

    private void gameOver() {
        System.out.println("Game over!");
        System.exit(0);
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            warrior.moveLeft();
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            warrior.moveRight();
        } else if (e.getKeyCode() == KeyEvent.VK_UP) {
            warrior.moveUp();
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            warrior.moveDown();
        }
    }
}
