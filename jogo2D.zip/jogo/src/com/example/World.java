public class World {

    private ArrayList<Enemy> enemies;

    public World() {
        enemies = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            enemies.add(new Enemy());
        }
    }

    public void update() {
        for (Enemy enemy : enemies) {
            enemy.update();
        }
    }

    public void render(Graphics g) {
        for (Enemy enemy : enemies) {
            enemy.render(g);
        }
    }

    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }
}
